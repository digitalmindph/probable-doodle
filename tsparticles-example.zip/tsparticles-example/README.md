# tsParticles example

A Pen created on CodePen.io. Original URL: [https://codepen.io/John-Romar-the-solid/pen/bGjJMOQ](https://codepen.io/John-Romar-the-solid/pen/bGjJMOQ).

This pen was created with tsParticles from https://particles.js.org